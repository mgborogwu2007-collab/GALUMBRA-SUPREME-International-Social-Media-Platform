import Link from "next/link";
import { getAuthenticatedUser, readDb } from "@/lib/data";

export default async function HomePage() {
  const db = await readDb();
  const user = await getAuthenticatedUser();

  return (
    <main className="min-h-screen bg-[#07130f] text-white">
      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6 lg:px-8">
        <div className="rounded-[28px] border border-emerald-500/10 bg-[#0d1b16]/85 shadow-[0_0_60px_rgba(16,185,129,0.15)] backdrop-blur-xl">
          <header className="flex items-center justify-between border-b border-white/10 px-5 py-4 sm:px-8">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 via-lime-500 to-cyan-400 font-black text-lg shadow-[0_10px_25px_rgba(16,185,129,0.35)]">
                N
              </div>
              <div>
                <div className="text-lg font-black tracking-[0.14em] text-white">NOURISH</div>
                <div className="text-[10px] uppercase tracking-[0.4em] text-slate-400">Social</div>
              </div>
            </div>

            <nav className="hidden items-center gap-2 md:flex">
              {[
                { label: "Home", href: "/" },
                { label: "Explore", href: "/explore" },
                { label: "Communities", href: "/communities" },
                { label: "Meals", href: "/messages" },
                { label: "Premium", href: "/premium" },
              ].map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="rounded-full px-4 py-2 text-sm font-medium text-slate-300 transition hover:bg-emerald-500/10 hover:text-white"
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              {user ? (
                <>
                  <Link
                    href="/profile"
                    className="rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-4 py-2 text-sm font-semibold text-white shadow-[0_10px_25px_rgba(16,185,129,0.45)] transition hover:brightness-110"
                  >
                    Profile
                  </Link>
                  <form action="/api/auth/logout" method="post">
                    <button className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200">
                      Logout
                    </button>
                  </form>
                </>
              ) : (
                <>
                  <Link href="/login" className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200">
                    Login
                  </Link>
                  <Link
                    href="/register"
                    className="rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-4 py-2 text-sm font-semibold text-white shadow-[0_10px_25px_rgba(16,185,129,0.45)] transition hover:brightness-110"
                  >
                    Join
                  </Link>
                </>
              )}
            </div>
          </header>

          <div className="grid gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[260px_minmax(0,1fr)_360px] lg:px-8">
            <aside className="space-y-6">
              <div className="rounded-[24px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 font-bold">
                    NS
                  </div>
                  <div>
                    <div className="text-base font-bold text-white">Nourish Social</div>
                    <div className="text-xs text-slate-400">@nourishsocial</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    [user ? user.followers : "18.4K", "Followers"],
                    [db.posts.length.toString(), "Posts"],
                    [user ? user.following : "482", "Following"],
                  ].map(([value, label]) => (
                    <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center">
                      <div className="text-lg font-black text-white">{value}</div>
                      <div className="text-[10px] uppercase tracking-[0.18em] text-slate-400">{label}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-[24px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex items-center justify-between">
                  <div className="text-xs uppercase tracking-[0.24em] text-slate-400">Navigation</div>
                  <span className="text-emerald-400">✦</span>
                </div>

                <div className="space-y-2">
                  {[
                    { label: "Home", href: "/", active: true },
                    { label: "Explore", href: "/explore" },
                    { label: "Challenges", href: "/messages" },
                    { label: "Communities", href: "/communities" },
                    { label: "Profile", href: "/profile" },
                  ].map((item) => (
                    <Link
                      key={item.label}
                      href={item.href}
                      className={`flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition ${item.active ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-white ring-1 ring-emerald-400/30" : "text-slate-300 hover:bg-white/5 hover:text-white"}`}
                    >
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">{item.label.charAt(0)}</div>
                      <span className="font-medium">{item.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </aside>

            <section className="space-y-6">
              <div className="rounded-[28px] border border-emerald-500/20 bg-gradient-to-r from-emerald-500/15 via-slate-900/80 to-cyan-500/15 p-5 sm:p-7">
                <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                  <div className="max-w-[720px]">
                    <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-[10px] uppercase tracking-[0.24em] text-emerald-200">
                      Fuel your better routine
                    </div>
                    <h1 className="text-4xl font-black leading-tight sm:text-5xl">
                      Eat better.
                      <span className="bg-gradient-to-r from-emerald-400 via-cyan-300 to-sky-500 bg-clip-text text-transparent">
                        Feel stronger.
                      </span>
                    </h1>
                    <p className="mt-4 max-w-xl text-base text-slate-300">
                      Nourish Social connects health-minded people, creators, and communities around realistic nutrition, meal inspiration, and sustainable habits.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    {user ? (
                      <>
                        <Link href="/profile" className="rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-5 py-3 font-semibold text-white shadow-[0_10px_25px_rgba(16,185,129,0.45)] transition hover:brightness-110">
                          My Routine
                        </Link>
                        <Link href="/explore" className="rounded-full border border-white/10 bg-white/5 px-5 py-3 font-semibold text-white transition hover:bg-white/10">
                          Explore
                        </Link>
                      </>
                    ) : (
                      <>
                        <Link href="/register" className="rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-5 py-3 font-semibold text-white shadow-[0_10px_25px_rgba(16,185,129,0.45)] transition hover:brightness-110">
                          Join now
                        </Link>
                        <Link href="/login" className="rounded-full border border-white/10 bg-white/5 px-5 py-3 font-semibold text-white transition hover:bg-white/10">
                          Login
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Active eaters", value: "1.8M" },
                  { label: "Healthy meals", value: "89K" },
                  { label: "Weekly goals", value: "4.8x" },
                  { label: "Creator revenue", value: "$8.4M" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-[22px] border border-white/10 bg-[#111827]/80 p-4">
                    <div className="text-xs uppercase tracking-[0.2em] text-slate-400">{stat.label}</div>
                    <div className="mt-3 text-3xl font-black text-white">{stat.value}</div>
                  </div>
                ))}
              </div>

              <div className="rounded-[24px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex items-center justify-between">
                  <div className="text-xs uppercase tracking-[0.24em] text-slate-400">Trending creators</div>
                  <Link href="/explore" className="text-sm font-medium text-emerald-300">View all</Link>
                </div>

                <div className="grid gap-4 lg:grid-cols-3">
                  {db.users.slice(0, 3).map((creator) => (
                    <div key={creator.id} className="rounded-[22px] border border-white/10 bg-gradient-to-br from-white/5 to-white/[0.03] p-4">
                      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 via-lime-500 to-cyan-500 text-xl font-black text-white shadow-[0_10px_25px_rgba(16,185,129,0.25)]">
                        {creator.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
                      </div>
                      <div className="text-lg font-bold text-white">{creator.name}</div>
                      <div className="mt-1 text-sm text-slate-400">@{creator.handle}</div>
                      <div className="mt-2 text-xs uppercase tracking-[0.18em] text-emerald-300">{creator.role}</div>
                      <div className="mt-4 flex items-center justify-between">
                        <div className="text-sm text-slate-300">{creator.followers} followers</div>
                        <button className="rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-200">
                          Follow
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-[26px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex gap-2">
                    {["For You", "Trending", "Challenges"].map((tab) => (
                      <button key={tab} className={`rounded-full px-4 py-2 text-sm font-medium transition ${tab === "For You" ? "bg-white text-slate-900" : "bg-white/5 text-slate-300 hover:bg-white/10"}`}>
                        {tab}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300">
                    <span>⌕</span>
                    <input className="w-40 bg-transparent text-sm text-white placeholder:text-slate-400 focus:outline-none" placeholder="Search" />
                  </div>
                </div>

                <div className="space-y-4">
                  {db.posts.slice(0, 3).map((post) => (
                    <article key={post.id} className="rounded-[26px] border border-white/10 bg-[#0b1220] p-4 sm:p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 via-lime-500 to-cyan-400 font-bold text-white">
                            {post.avatar}
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <div className="font-bold text-white">{post.author}</div>
                              <div className="text-sm text-slate-400">@{post.authorHandle}</div>
                            </div>
                            <div className="text-xs uppercase tracking-[0.14em] text-slate-500">
                              {post.role} • {post.createdAt}
                            </div>
                          </div>
                        </div>
                        <button className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-slate-300">•••</button>
                      </div>

                      <div className="mt-4 text-[16px] leading-7 text-slate-200">{post.content}</div>

                      {post.tags.length > 0 && (
                        <div className="mt-3 flex flex-wrap gap-2">
                          {post.tags.map((tag) => (
                            <span key={tag} className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-200">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}

                      {post.image && (
                        <div className="mt-4 overflow-hidden rounded-[22px] border border-white/10">
                          <img src={post.image} alt="Post" className="h-[260px] w-full object-cover sm:h-[320px]" />
                        </div>
                      )}

                      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4">
                        <div className="flex items-center gap-5 text-sm text-slate-300">
                          <button className="flex items-center gap-2 transition hover:text-pink-300"><span>♥</span> {post.likes}</button>
                          <button className="flex items-center gap-2 transition hover:text-cyan-300"><span>💬</span> {post.comments}</button>
                          <button className="flex items-center gap-2 transition hover:text-violet-300"><span>↻</span> {post.shares}</button>
                        </div>
                        <button className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-sm font-medium text-slate-300 transition hover:bg-white/10">
                          Save
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            </section>

            <aside className="space-y-6">
              <div className="rounded-[24px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex items-center justify-between">
                  <div className="text-xs uppercase tracking-[0.24em] text-slate-400">Trending</div>
                  <span className="text-emerald-400">↗</span>
                </div>
                <div className="space-y-3">
                  {[
                    ["#MealPrep", "182K"],
                    ["#PlantFuel", "94K"],
                    ["#HealthyHabits", "63K"],
                    ["#ProteinBoost", "41K"],
                  ].map(([topic, count], index) => (
                    <div key={topic} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-3 py-3">
                      <div>
                        <div className="font-semibold text-white">{topic}</div>
                        <div className="text-xs text-slate-400">{count} conversations</div>
                      </div>
                      <div className="text-xs uppercase tracking-[0.18em] text-slate-500">#{index + 1}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-[24px] border border-white/10 bg-gradient-to-br from-emerald-500/15 via-lime-500/10 to-cyan-500/10 p-4">
                <div className="mb-3 flex items-center gap-2 text-emerald-200"><span>★</span><div className="text-xs uppercase tracking-[0.22em]">Premium</div></div>
                <h3 className="text-2xl font-black text-white">Build a stronger routine.</h3>
                <p className="mt-2 text-sm leading-6 text-slate-300">
                  Unlock meal plans, guided habit tracking, expert nutrition coaching, and premium community programs.
                </p>
                <Link href="/premium" className="mt-5 block w-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 px-4 py-3 text-center font-semibold text-white shadow-[0_12px_28px_rgba(16,185,129,0.35)]">
                  Upgrade to Premium
                </Link>
              </div>

              <div className="rounded-[24px] border border-white/10 bg-[#111827]/80 p-4">
                <div className="mb-4 flex items-center justify-between">
                  <div className="text-xs uppercase tracking-[0.24em] text-slate-400">Live now</div>
                  <div className="flex items-center gap-2 text-green-400"><span className="h-2 w-2 rounded-full bg-green-400" /><span className="text-xs font-medium">Online</span></div>
                </div>
                <div className="space-y-3">
                  {[
                    "Meal prep room — high protein ideas",
                    "Hydration challenge — 7-day reset",
                    "Healthy kitchen club — meal swaps",
                  ].map((item) => (
                    <div key={item} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 p-3">
                      <div className="text-sm text-white">{item}</div>
                      <span className="text-cyan-300">◉</span>
                    </div>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </main>
  );
}