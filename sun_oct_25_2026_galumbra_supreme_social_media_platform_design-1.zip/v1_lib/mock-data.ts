export const creatorCards = [
  {
    name: "Ari Cole",
    handle: "@aricole",
    niche: "Plant-based coach",
    followers: "1.4M",
    accent: "from-emerald-500 via-lime-500 to-cyan-500",
  },
  {
    name: "Nia Brooks",
    handle: "@niabrooks",
    niche: "Healthy living",
    followers: "820K",
    accent: "from-cyan-500 via-sky-500 to-indigo-500",
  },
  {
    name: "Miles Hart",
    handle: "@mileshart",
    niche: "Strength + meals",
    followers: "2.1M",
    accent: "from-amber-400 via-orange-500 to-rose-500",
  },
];

export const stats = [
  { label: "Active eaters", value: "1.8M" },
  { label: "Healthy meals", value: "89K" },
  { label: "Weekly goals", value: "4.8x" },
  { label: "Creator revenue", value: "$8.4M" },
];

export const trendTopics = [
  { topic: "#MealPrep", posts: "182K" },
  { topic: "#PlantFuel", posts: "94K" },
  { topic: "#HealthyHabits", posts: "63K" },
  { topic: "#ProteinBoost", posts: "41K" },
  { topic: "#CleanEating", posts: "28K" },
];

export type Post = {
  id: number;
  author: string;
  handle: string;
  role: string;
  avatar: string;
  time: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
  tags: string[];
};

export const posts: Post[] = [
  {
    id: 1,
    author: "Maya Evans",
    handle: "@mayaeats",
    role: "Nutrition coach",
    avatar: "ME",
    time: "2h ago",
    content:
      "A realistic nutrition plan is not about restriction. It is about consistency, energy, and meals that feel good enough to keep repeating.",
    image:
      "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1200&q=80",
    likes: 18240,
    comments: 3412,
    shares: 968,
    tags: ["#MealPrep", "#CleanEating", "#Energy"],
  },
  {
    id: 2,
    author: "Daniel Lee",
    handle: "@danielleefit",
    role: "Strength trainer",
    avatar: "DL",
    time: "5h ago",
    content:
      "Your meals should support your training, not interrupt it. Protein, fiber, and hydration are the real foundation of consistency.",
    likes: 24010,
    comments: 1840,
    shares: 1320,
    tags: ["#ProteinBoost", "#GymFuel", "#Hydration"],
  },
  {
    id: 3,
    author: "Sofia Reed",
    handle: "@sofiawellness",
    role: "Wellness creator",
    avatar: "SR",
    time: "8h ago",
    content:
      "The easiest healthy routine is the one your week can actually sustain. Small wins compound into a stronger body and calmer mind.",
    likes: 16320,
    comments: 2198,
    shares: 778,
    tags: ["#HealthyHabits", "#MindfulEating", "#Wellness"],
  },
];

export const communities = [
  { name: "Meal Prep Crew", members: "170K", focus: "High-protein recipes" },
  { name: "Plant Fuel Circle", members: "92K", focus: "Vegan + sustainable nutrition" },
  { name: "Hydration Club", members: "64K", focus: "Daily wellness habits" },
  { name: "Fit Kitchen", members: "41K", focus: "Balanced routines" },
];

export const messages = [
  { name: "Ari Cole", preview: "I added a new 7-day high-protein plan.", time: "1m" },
  { name: "Nia Brooks", preview: "The green smoothie challenge is working great.", time: "8m" },
  { name: "Miles Hart", preview: "Need ideas for easy post-workout meals.", time: "20m" },
];

export const profileHighlights = [
  { label: "Followers", value: "18.4K" },
  { label: "Following", value: "482" },
  { label: "Posts", value: "2.8K" },
  { label: "Engagement", value: "9.7%" },
];

export const quickLinks = [
  { href: "/", label: "Home" },
  { href: "/explore", label: "Explore" },
  { href: "/communities", label: "Communities" },
  { href: "/messages", label: "Meals" },
  { href: "/profile", label: "Profile" },
  { href: "/premium", label: "Premium" },
];