import React, { useEffect, useState } from 'react';
import {
  Home, Compass, PlusSquare, MessageCircle, Music2, Radio, Bot, Wallet,
  Crown, Search, Bell, Menu, X, Heart, MessageSquare, Share2, Bookmark,
  Image as ImageIcon, Video, LogOut, UserRound, Sparkles, ArrowRight, CheckCircle2
} from 'lucide-react';
import { supabase, configured } from './supabase';

// Pricing option B: each level costs ₦1,300 × level number.
// NGN is the canonical pricing currency; other currencies are indicative conversions.
const tierPriceNgn = level => level === 0 ? 0 : level * 1300;
const COUNTRY_CURRENCIES = {
  'Nigeria':'NGN','United States':'USD','United Kingdom':'GBP','Canada':'CAD','Australia':'AUD',
  'New Zealand':'NZD','Ghana':'GHS','Kenya':'KES','South Africa':'ZAR','India':'INR',
  'Pakistan':'PKR','Bangladesh':'BDT','Uganda':'UGX','Tanzania':'TZS','Rwanda':'RWF',
  'Egypt':'EGP','United Arab Emirates':'AED','Saudi Arabia':'SAR','Germany':'EUR','France':'EUR',
  'Italy':'EUR','Spain':'EUR','Ireland':'EUR','Netherlands':'EUR','Portugal':'EUR','Japan':'JPY',
  'China':'CNY','Singapore':'SGD','Malaysia':'MYR','Indonesia':'IDR','Philippines':'PHP',
  'Brazil':'BRL','Mexico':'MXN','Argentina':'ARS','Switzerland':'CHF','Turkey':'TRY',
  'South Korea':'KRW','Thailand':'THB','Vietnam':'VND','Israel':'ILS','Sweden':'SEK',
  'Norway':'NOK','Denmark':'DKK','Poland':'PLN','Ukraine':'UAH','Morocco':'MAD'
};
const COUNTRY_NAMES = Object.keys(COUNTRY_CURRENCIES).sort();
const tierPrice = (level, currency, rates) => {
  const ngn = tierPriceNgn(level);
  const target = currency || 'NGN';
  if (target === 'NGN') return ngn;
  // FX endpoint is USD-based, so convert NGN -> USD -> target currency.
  if (!rates?.NGN || !rates?.[target]) return null;
  return (ngn / rates.NGN) * rates[target];
};
const formatMoney = (amount, currency) => {
  if (amount === null || amount === undefined) return 'Loading exchange rate…';
  try { return new Intl.NumberFormat(undefined,{style:'currency',currency:currency||'NGN',maximumFractionDigits:['JPY','KRW'].includes(currency)?0:2}).format(amount); }
  catch { return `${currency||'NGN'} ${Number(amount).toLocaleString()}`; }
};

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [active, setActive] = useState('Home');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const [posts, setPosts] = useState([]);
  const [postText, setPostText] = useState('');
  const [postBusy, setPostBusy] = useState(false);
  const [search, setSearch] = useState('');
  const [tierSearch, setTierSearch] = useState('');
  const [selectedTier, setSelectedTier] = useState(0);
  const [country, setCountry] = useState('Nigeria');
  const [currency, setCurrency] = useState('NGN');
  const [fxRates, setFxRates] = useState({USD:1});
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({full_name:'',country:'Nigeria',phone:'',street:'',city:'',region:'',postal_code:'',id_type:'',id_country:'Nigeria'});
  const [bankCountry, setBankCountry] = useState('Nigeria');
  const [bankName, setBankName] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [notice, setNotice] = useState('');
  const [liked, setLiked] = useState([]);
  const [saved, setSaved] = useState([]);
  const [chatText, setChatText] = useState('');
  const [chat, setChat] = useState([{role:'assistant', text:'Welcome to Galumbra Supreme. I’m the in-app assistant interface. Connect an AI provider to enable live AI responses.'}]);

  useEffect(() => {
    let alive = true;
    fetch('https://open.er-api.com/v6/latest/USD').then(r => r.ok ? r.json() : Promise.reject())
      .then(data => { if (alive && data?.rates) setFxRates(data.rates); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  useEffect(() => { setCurrency(COUNTRY_CURRENCIES[country] || 'USD'); }, [country]);

  useEffect(() => {
    if (!configured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!configured) {
      setPosts([
        {id:'sample-1', author:'Galumbra Team', body:'Welcome to the Galumbra Supreme workspace. Connect your database to publish posts that other signed-in users can see.', created_at:new Date().toISOString(), likes:12},
        {id:'sample-2', author:'Creator spotlight', body:'Your next big idea deserves a place to grow. Create, share, discover, and build your community.', created_at:new Date(Date.now()-3600000).toISOString(), likes:7}
      ]);
      return;
    }
    loadPosts();
  }, [configured, session]);

  useEffect(() => {
    if (session?.user) loadProfile();
    else setProfile(null);
  }, [session]);

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (data) setProfile(data);
    else {
      const display = session.user.user_metadata?.full_name || session.user.email?.split('@')[0] || 'New member';
      const { data: created } = await supabase.from('profiles').insert({id:session.user.id, username:display.toLowerCase().replace(/[^a-z0-9_]/g,'_').slice(0,24), display_name:display}).select().single();
      setProfile(created || null);
    }
  }

  async function loadPosts() {
    const { data, error } = await supabase.from('posts').select('id, body, created_at, author_id, profiles(display_name, username)').order('created_at', {ascending:false}).limit(50);
    if (!error && data) setPosts(data.map(p => ({...p, author:p.profiles?.display_name || p.profiles?.username || 'Galumbra member', likes:0})));
  }

  async function signIn(e) {
    e.preventDefault(); setAuthMessage('');
    if (!configured) { setAuthMessage('First connect Supabase using the setup guide. This screen cannot create real accounts until the backend is connected.'); return; }
    if (authMode === 'phone') {
      const { error } = await supabase.auth.signInWithOtp({ phone });
      setAuthMessage(error ? error.message : 'SMS code requested. Enter the code in your Supabase-authenticated flow; SMS provider setup is required.');
      return;
    }
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({email, password})
      : await supabase.auth.signInWithPassword({email, password});
    setAuthMessage(result.error ? result.error.message : (authMode === 'signup' ? 'Check your email to confirm your account.' : 'You are signed in.'));
  }

  async function saveProfile(e) {
    e.preventDefault();
    if (!session || !configured) { setNotice('Connect the backend and sign in before saving a real profile.'); return; }
    const payload = {id:session.user.id, username:(profileForm.full_name || session.user.email?.split('@')[0] || 'member').toLowerCase().replace(/[^a-z0-9_]/g,'_').slice(0,24),
      display_name:profileForm.full_name || 'New member', country:profileForm.country, phone:profileForm.phone,
      street:profileForm.street, city:profileForm.city, region:profileForm.region, postal_code:profileForm.postal_code,
      preferred_currency:currency, id_type:profileForm.id_type, id_country:profileForm.id_country};
    const {error}=await supabase.from('profiles').upsert(payload);
    if(error) setNotice(error.message);
    else {setProfile({...profile,...payload});setCountry(profileForm.country);setProfileOpen(false);setNotice('Profile saved. Government ID verification must be completed through a secure verification provider.');}
  }

  async function requestWithdrawal(e) {
    e.preventDefault();
    setNotice('No withdrawal was submitted. A payout provider, verified account ownership, transaction ledger, and security checks must be connected first.');
  }

  async function signOut() { if (configured) await supabase.auth.signOut(); setNotice('Signed out.'); }

  async function createPost(e) {
    e.preventDefault();
    if (!postText.trim()) return;
    if (!session) { setAuthOpen(true); setNotice('Sign in before publishing a post.'); return; }
    if (!configured) { setNotice('Connect Supabase to publish posts across accounts.'); return; }
    setPostBusy(true);
    const { error } = await supabase.from('posts').insert({author_id:session.user.id, body:postText.trim()});
    setPostBusy(false);
    if (error) setNotice(error.message);
    else { setPostText(''); setNotice('Post published.'); loadPosts(); }
  }

  async function requestPlan() {
    if (!session) { setAuthOpen(true); setNotice('Sign in before requesting a membership plan.'); return; }
    if (!configured) { setNotice('Connect the backend first. Payment processing is not yet connected, so no payment has been taken.'); return; }
    const { error } = await supabase.from('plan_requests').insert({user_id:session.user.id, tier_level:selectedTier, amount_ngn:tierPriceNgn(selectedTier), display_currency:currency, display_amount:tierPrice(selectedTier,currency,fxRates) === null ? null : Math.round(tierPrice(selectedTier,currency,fxRates)*100)/100, status:'pending'});
    setNotice(error ? error.message : 'Plan request recorded. An administrator must confirm payment before activation.');
  }

  function sendChat(e) {
    e.preventDefault(); if (!chatText.trim()) return;
    const userText = chatText.trim();
    setChat(prev => [...prev, {role:'user', text:userText}, {role:'assistant', text:'The chat interface is ready, but live AI is not connected yet. A secure server-side AI integration is needed before this assistant can answer using a real AI model.'}]);
    setChatText('');
  }

  const nav = [
    ['Home',Home],['Explore',Compass],['Create',PlusSquare],['Messenger',MessageCircle],
    ['Music Studio',Music2],['Live',Radio],['AI Assistant',Bot],['Membership',Crown],['Wallet',Wallet]
  ];
  const tierNum = Math.max(0, Math.min(1000, Number(tierSearch) || 0));
  const shownTiers = tierSearch === '' ? [0,1,2,3,4,5,10,25,50,100,250,500,750,1000] : [tierNum];

  function navTo(name) { setActive(name); setMobileMenu(false); setNotice(''); }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu?'open':''}`}>
      <div className="brand"><div className="brand-mark">G<span>+</span></div><div><strong>GALUMBRA</strong><small>SUPREME</small></div><button className="icon-btn close-menu" onClick={()=>setMobileMenu(false)}><X size={18}/></button></div>
      <button className="primary-btn create-btn" onClick={()=>navTo('Create')}><PlusSquare size={18}/> Create post</button>
      <div className="nav-label">YOUR SPACE</div>
      <nav>{nav.map(([name,Icon])=><button key={name} className={`nav-item ${active===name?'selected':''}`} onClick={()=>navTo(name)}><Icon size={19}/><span>{name}</span>{name==='Messenger'&&<i className="nav-dot"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="status-pill"><span className={configured?'status-green':'status-amber'}></span>{configured?'Backend configured':'Setup required'}</div><p>Build your world.<br/><b>Grow together.</b></p><button className="nav-item" onClick={()=>setAuthOpen(true)}><UserRound size={19}/><span>{session?'Account':'Sign in / Join'}</span></button>{session&&<button className="nav-item" onClick={signOut}><LogOut size={19}/><span>Sign out</span></button>}</div>
    </aside>
    {mobileMenu&&<button className="scrim" aria-label="Close menu" onClick={()=>setMobileMenu(false)}/>}
    <main className="main">
      <header className="topbar"><button className="icon-btn menu-toggle" onClick={()=>setMobileMenu(true)}><Menu/></button><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search Galumbra Supreme"/></div><button className="icon-btn notification" onClick={()=>setNotice('Notifications will appear here when the notification service is connected.')}><Bell size={19}/></button><button className="avatar" onClick={()=>session?setProfileOpen(true):setAuthOpen(true)}>{(profile?.display_name||session?.user?.email||'G').slice(0,1).toUpperCase()}</button></header>
      <div className="content">
        <section className="welcome"><div><div className="eyebrow"><Sparkles size={14}/> A NEW DIGITAL WORLD</div><h1>{active==='Home'?'Your world. Your voice.':active}</h1><p>{active==='Home'?'Connect with people, share what matters, and grow your ideas.':'Explore the Galumbra Supreme '+active.toLowerCase()+' workspace.'}</p></div><div className="welcome-orb"><div className="orb-inner">G</div></div></section>
        {!configured&&<div className="setup-banner"><div><strong>Connect the real backend to go live</strong><p>This site currently runs in preview mode. Add your Supabase project keys and run the included database SQL to enable real accounts and shared posts.</p></div><a href="https://supabase.com" target="_blank" rel="noreferrer">Set up backend <ArrowRight size={15}/></a></div>}
        {notice&&<div className="notice"><span>{notice}</span><button onClick={()=>setNotice('')}><X size={15}/></button></div>}
        {(active==='Home'||active==='Explore')&&<div className="columns">
          <div className="feed">
            <div className="section-heading"><h2>{active==='Home'?'Your feed':'Discover'}</h2><button className="text-btn" onClick={loadPosts}>Refresh</button></div>
            <form className="composer card" onSubmit={createPost}><div className="composer-top"><div className="avatar large">{(profile?.display_name||'G').slice(0,1).toUpperCase()}</div><textarea value={postText} onChange={e=>setPostText(e.target.value)} placeholder={session?'What would you like to share?':'Sign in to publish a post'} rows="2"/></div><div className="composer-actions"><div className="muted-actions"><span><ImageIcon size={17}/> Photo (coming soon)</span><span><Video size={17}/> Video (coming soon)</span></div><button className="primary-btn" disabled={postBusy}>{postBusy?'Publishing…':'Publish'}</button></div></form>
            {posts.filter(p=>!search||`${p.author} ${p.body}`.toLowerCase().includes(search.toLowerCase())).map(post=><article className="card post" key={post.id}><div className="post-head"><div className="avatar">{post.author?.slice(0,1).toUpperCase()||'G'}</div><div className="post-author"><strong>{post.author}</strong><small>{new Date(post.created_at).toLocaleString()}</small></div><button className="more-btn" onClick={()=>setNotice('Post options will be added with moderation and reporting tools.')}>•••</button></div><p className="post-body">{post.body}</p><div className="post-stats"><span>{post.likes||0} likes</span><span>Comments require the comments backend module</span></div><div className="post-actions"><button className={liked.includes(post.id)?'active-action':''} onClick={()=>setLiked(v=>v.includes(post.id)?v.filter(x=>x!==post.id):[...v,post.id])}><Heart size={18}/> Like</button><button onClick={()=>setNotice('Comments are not yet connected to a database table.')}><MessageSquare size={18}/> Comment</button><button onClick={()=>setNotice('Share link feature will be enabled after public hosting.')}><Share2 size={18}/> Share</button><button onClick={()=>setSaved(v=>v.includes(post.id)?v.filter(x=>x!==post.id):[...v,post.id])} className={saved.includes(post.id)?'active-action':''}><Bookmark size={18}/> Save</button></div></article>)}
            {posts.length===0&&<div className="empty card"><Sparkles/><h3>Your feed starts here</h3><p>Be the first to share something with the community.</p></div>}
          </div>
          <aside className="right-rail"><div className="card side-card"><div className="side-title"><h3>Membership</h3><Crown size={19}/></div><p>Start free and choose a level when you are ready.</p><div className="price-highlight"><small>Top level</small><strong>{formatMoney(tierPrice(1000,currency,fxRates),currency)}</strong><span>Galumbra Apex</span></div><button className="outline-btn full" onClick={()=>navTo('Membership')}>Explore levels <ArrowRight size={16}/></button></div><div className="card side-card"><div className="side-title"><h3>Creator tools</h3><Sparkles size={18}/></div><button className="tool-row" onClick={()=>navTo('Music Studio')}><Music2 size={18}/><span>Music Studio</span><ArrowRight size={15}/></button><button className="tool-row" onClick={()=>navTo('AI Assistant')}><Bot size={18}/><span>AI Assistant</span><ArrowRight size={15}/></button><button className="tool-row" onClick={()=>navTo('Live')}><Radio size={18}/><span>Go Live</span><ArrowRight size={15}/></button></div><div className="card side-card community"><h3>Galumbra community</h3><p>Follow our official channels as the platform develops.</p><a href="https://www.tiktok.com/@galumbrasupremeaeu216" target="_blank" rel="noreferrer">TikTok ↗</a><a href="https://wa.me/2347033068095" target="_blank" rel="noreferrer">WhatsApp ↗</a></div></aside>
        </div>}
        {active==='Create'&&<div className="single-panel card"><h2>Create a post</h2><p>Write something for the community. Posts will be shared with signed-in users after backend setup.</p><form onSubmit={createPost}><textarea className="big-textarea" rows="7" value={postText} onChange={e=>setPostText(e.target.value)} placeholder="Tell your story…"/><div className="form-foot"><span>Photo and video uploads are not enabled yet.</span><button className="primary-btn" disabled={postBusy}>{postBusy?'Publishing…':'Publish post'}</button></div></form></div>}
        {active==='Membership'&&<div className="membership-wrap"><div className="membership-intro"><div className="eyebrow"><Crown size={14}/> MEMBERSHIP LEVELS</div><h2>Start free. Rise on your terms.</h2><p>Prices use USD as the reference and are displayed in your selected currency using indicative exchange rates. You can change the display currency. Final checkout amounts must be confirmed by a payment provider.</p></div><div className="currency-controls card"><label>Country<select value={country} onChange={e=>setCountry(e.target.value)}>{COUNTRY_NAMES.map(c=><option key={c}>{c}</option>)}</select></label><label>Display currency<select value={currency} onChange={e=>setCurrency(e.target.value)}>{[...new Set(Object.values(COUNTRY_CURRENCIES).concat(['USD','EUR','GBP','NGN','CAD','AUD','JPY','INR']))].sort().map(c=><option key={c} value={c}>{c}</option>)}</select></label><span className="fx-note">Indicative exchange rates · not a payment quote</span></div>
        <div className="tier-search"><Search size={18}/><input type="number" min="0" max="1000" value={tierSearch} onChange={e=>setTierSearch(e.target.value)} placeholder="Enter a level number (0–1000)"/><span>Level 0–1000</span></div><div className="tier-grid">{shownTiers.map(level=><div className={`tier-card ${level===selectedTier?'tier-selected':''}`} key={level}><div className="tier-top"><span className="tier-badge">{level===0?'FREE':`LEVEL ${level}`}</span>{level===1000&&<Crown size={19}/>}</div><h3>{level===0?'Open Access':level===1000?'Galumbra Apex':`Galumbra Level ${level}`}</h3><div className="tier-price">{level===0?formatMoney(0,currency):formatMoney(tierPrice(level,currency,fxRates),currency)}<small>{level===0?'forever':'planned price'}</small></div><ul><li><CheckCircle2 size={15}/> Community access</li><li><CheckCircle2 size={15}/> Member profile</li><li><CheckCircle2 size={15}/> Level badge</li></ul><button className={level===selectedTier?'primary-btn full':'outline-btn full'} onClick={()=>setSelectedTier(level)}>{level===selectedTier?'Selected':'Choose level'}</button></div>)}</div><div className="tier-purchase card"><div><strong>Selected: {selectedTier===0?'Open Access':selectedTier===1000?'Galumbra Apex':`Galumbra Level ${selectedTier}`}</strong><p>{selectedTier===0?'Free membership.':`Planned amount: ${formatMoney(tierPrice(selectedTier,currency,fxRates),currency)}. No payment will be taken by this prototype.`}</p></div><button className="primary-btn" onClick={requestPlan}>{selectedTier===0?'Join free':'Request this level'} <ArrowRight size={16}/></button></div><p className="fine-print">Important: membership levels and prices are a proposed structure, not a promise of earnings or benefits. Payments are not active yet. Before collecting money, define exactly what each level provides, publish terms/refund rules, and connect a verified payment provider.</p></div>}
        {active==='AI Assistant'&&<div className="chat-panel card"><div className="chat-header"><div className="ai-icon"><Bot/></div><div><h2>Galumbra AI</h2><p>Assistant workspace · provider not connected</p></div></div><div className="chat-messages">{chat.map((m,i)=><div key={i} className={`chat-bubble ${m.role}`}>{m.text}</div>)}</div><form className="chat-form" onSubmit={sendChat}><input value={chatText} onChange={e=>setChatText(e.target.value)} placeholder="Ask Galumbra AI…"/><button className="primary-btn">Send</button></form></div>}
        {active==='Messenger'&&<div className="feature-card card"><MessageCircle size={34}/><h2>Messenger</h2><p>The messaging screen is planned, but real private messaging needs conversations, message storage, realtime subscriptions, reporting, and blocking controls in the backend. No messages are sent from this placeholder screen.</p><button className="outline-btn" onClick={()=>setNotice('Messaging backend is the next development module.')}>Show status</button></div>}
        {active==='Music Studio'&&<div className="feature-card card"><Music2 size={34}/><h2>Music Studio</h2><p>Studio workspace reserved for recording, audio tracks, beats, and project saving. Real audio recording and music export are not enabled in this starter.</p><div className="studio-pads">{['Record vocals','Beat library','Mix tracks','Export audio'].map(x=><button key={x} onClick={()=>setNotice(`${x} is planned; audio engine is not connected yet.`)}>{x}</button>)}</div></div>}
        {active==='Live'&&<div className="feature-card card"><Radio size={34}/><h2>Live streaming</h2><p>Live streaming needs a streaming provider, stream keys, moderation, and bandwidth/storage billing. This starter does not broadcast video.</p><button className="outline-btn" onClick={()=>setNotice('Live streaming is not active; no broadcast has started.')}>Check status</button></div>}
        {active==='Wallet'&&<div className="feature-card card"><Wallet size={34}/><h2>Wallet & withdrawals</h2><p>This wallet is a preview only and does not hold money or send payouts.</p><div className="wallet-balance"><small>Display currency: {currency}</small><strong>{formatMoney(0,currency)}</strong><span>Not a real account balance</span></div><form className="withdraw-form" onSubmit={requestWithdrawal}><h3>Bank withdrawal setup</h3><label>Country<select value={bankCountry} onChange={e=>setBankCountry(e.target.value)}>{COUNTRY_NAMES.map(c=><option key={c}>{c}</option>)}</select></label><label>Bank / payout provider<input value={bankName} onChange={e=>setBankName(e.target.value)} placeholder="Bank name"/></label><label>Account holder<input value={accountHolder} onChange={e=>setAccountHolder(e.target.value)} placeholder="Account holder's name"/></label><label>Account number / IBAN<input value={accountNumber} onChange={e=>setAccountNumber(e.target.value)} placeholder="Account number"/></label><label>Amount ({currency})<input value={withdrawAmount} onChange={e=>setWithdrawAmount(e.target.value)} type="number" min="0" step="0.01" placeholder="0.00"/></label><button className="primary-btn">Check withdrawal setup</button><p className="fine-print">Supported banks must be loaded from a payout provider's live directory. Coverage depends on the country and provider; this form does not transfer money.</p></form></div>}
        {active==='Profile'&&<div className="feature-card card"><UserRound size={34}/><h2>Your profile</h2><p>{session?.user?.email||'Sign in to see your account.'}</p><button className="outline-btn" onClick={()=>setAuthOpen(true)}>Account settings</button></div>}
        {!['Home','Explore','Create','Membership','AI Assistant','Messenger','Music Studio','Live','Wallet','Profile'].includes(active)&&<div className="feature-card card"><Sparkles size={34}/><h2>{active}</h2><p>This section is reserved for the next development module.</p></div>}
        <footer className="footer"><span>© {new Date().getFullYear()} Galumbra Supreme</span><span>Website starter · Mobile + desktop</span></footer>
      </div>
    </main>
    {profileOpen&&<div className="modal-backdrop" onClick={()=>setProfileOpen(false)}><div className="profile-modal card" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setProfileOpen(false)}><X/></button><h2>Complete your member profile</h2><p>Fill in the details needed for your account and local currency.</p><form onSubmit={saveProfile}><label>Full legal name<input required value={profileForm.full_name} onChange={e=>setProfileForm({...profileForm,full_name:e.target.value})}/></label><label>Country<select required value={profileForm.country} onChange={e=>{setProfileForm({...profileForm,country:e.target.value,id_country:e.target.value});setCountry(e.target.value)}}>{COUNTRY_NAMES.map(c=><option key={c}>{c}</option>)}</select></label><label>Phone number<input required value={profileForm.phone} onChange={e=>setProfileForm({...profileForm,phone:e.target.value})} placeholder="+234..."/></label><label>Street address<input required value={profileForm.street} onChange={e=>setProfileForm({...profileForm,street:e.target.value})}/></label><div className="two-fields"><label>City<input required value={profileForm.city} onChange={e=>setProfileForm({...profileForm,city:e.target.value})}/></label><label>State / region<input value={profileForm.region} onChange={e=>setProfileForm({...profileForm,region:e.target.value})}/></label></div><label>Postal code<input value={profileForm.postal_code} onChange={e=>setProfileForm({...profileForm,postal_code:e.target.value})}/></label><label>ID document type<select value={profileForm.id_type} onChange={e=>setProfileForm({...profileForm,id_type:e.target.value})}><option value="">Select document type</option><option>National ID</option><option>Passport</option><option>Driver's licence</option><option>Other government ID</option></select></label><div className="privacy-warning"><strong>Protect your identity:</strong> Do not enter your NIN, passport number, or other government ID number into this ordinary profile form. A secure KYC provider should verify it; the general profile database should not store raw ID numbers.</div><button className="primary-btn full">Save profile</button></form></div></div>}
    {authOpen&&<div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="auth-modal card" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setAuthOpen(false)}><X/></button><div className="brand modal-brand"><div className="brand-mark">G<span>+</span></div><div><strong>GALUMBRA</strong><small>SUPREME</small></div></div><h2>{authMode==='signup'?'Join Galumbra Supreme':authMode==='phone'?'Phone verification':'Welcome back'}</h2><p>Real account access becomes available after you connect your Supabase project.</p><div className="auth-tabs"><button className={authMode==='signup'?'current':''} onClick={()=>{setAuthMode('signup');setAuthMessage('')}}>Create account</button><button className={authMode==='login'?'current':''} onClick={()=>{setAuthMode('login');setAuthMessage('')}}>Sign in</button><button className={authMode==='phone'?'current':''} onClick={()=>{setAuthMode('phone');setAuthMessage('')}}>Phone OTP</button></div><form onSubmit={signIn}>{authMode==='phone'?<label>Phone number with country code<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+234..." required/></label>:<><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required/></label><label>Password<input type="password" minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" required/></label></>}<button className="primary-btn full">{authMode==='signup'?'Create account':authMode==='login'?'Sign in':'Request SMS code'}</button></form>{authMessage&&<div className="auth-message">{authMessage}</div>}<div className="auth-note">Google sign-in can be added in Supabase settings after the first release.</div></div></div>}
  </div>;
}
export default App;